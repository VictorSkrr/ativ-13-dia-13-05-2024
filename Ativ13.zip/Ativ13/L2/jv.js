document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const salario = parseFloat(document.getElementById('salario').value);

    const descontoINSS = salario * 0.08;
    const salarioLiquido = salario - descontoINSS;

    document.getElementById('nomeResultado').textContent = nome;
    document.getElementById('salarioBruto').textContent = salario.toFixed(2);
    document.getElementById('valorINSS').textContent = descontoINSS.toFixed(2);
    document.getElementById('salarioLiquido').textContent = salarioLiquido.toFixed(2);

    document.getElementById('resultado').classList.remove('hidden');
});
