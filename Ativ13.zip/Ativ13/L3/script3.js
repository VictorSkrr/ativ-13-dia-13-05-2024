document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const salario = parseFloat(document.getElementById('salario').value);
    let taxaDesconto, valorDesconto;

    if (salario <= 1000) {
        taxaDesconto = 8;
    } else if (salario <= 1500) {
        taxaDesconto = 8.5;
    } else {
        taxaDesconto = 9;
    }

    valorDesconto = (salario * taxaDesconto) / 100;
    const salarioLiquido = salario - valorDesconto;

    document.getElementById('nomeResultado').textContent = nome;
    document.getElementById('salarioBruto').textContent = salario.toFixed(2);
    document.getElementById('taxaDesconto').textContent = taxaDesconto.toFixed(2);
    document.getElementById('valorDesconto').textContent = valorDesconto.toFixed(2);
    document.getElementById('salarioLiquido').textContent = salarioLiquido.toFixed(2);

    document.getElementById('resultado').classList.remove('hidden');
});
